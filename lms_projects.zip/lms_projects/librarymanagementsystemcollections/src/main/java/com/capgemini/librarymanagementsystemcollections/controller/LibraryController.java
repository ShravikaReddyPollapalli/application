package com.capgemini.librarymanagementsystemcollections.controller;

public class LibraryController {
	public static void main(String[] args) {
		Library.doReg();
	}//End of main method
}//End of class
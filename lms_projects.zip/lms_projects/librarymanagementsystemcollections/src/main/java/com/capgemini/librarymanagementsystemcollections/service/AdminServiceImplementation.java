package com.capgemini.librarymanagementsystemcollections.service;

import java.util.List;

import com.capgemini.librarymanagementsystemcollections.dao.AdminDAO;
import com.capgemini.librarymanagementsystemcollections.dto.AdminDetails;
import com.capgemini.librarymanagementsystemcollections.dto.BookDetails;
import com.capgemini.librarymanagementsystemcollections.dto.RequestBeans;
import com.capgemini.librarymanagementsystemcollections.dto.UserDetails;
import com.capgemini.librarymanagementsystemcollections.factory.LibraryFactory;



public class AdminServiceImplementation implements AdminService{
	private AdminDAO dao = LibraryFactory.getAdminDao();

	
	public boolean registerAdmin(AdminDetails admin) {
		return dao.registerAdmin(admin);
	}

	
	public AdminDetails loginAdmin(String email, String password) {
		return dao.loginAdmin(email, password);
	}

	
	public boolean addBook(BookDetails book) {
		return dao.addBook(book);
	}

	
	public boolean removeBook(int id) {
		return dao.removeBook(id);
	}
	
	
	public List<BookDetails> searchBookByTitle(String bookName) {
		return dao.searchBookByTitle(bookName);
	}

	
	public List<BookDetails> searchBookByAuthor(String author) {
		return dao.searchBookByAuthor(author);
	}

	
	public List<BookDetails> searchBookByCategory(String category) {
		return dao.searchBookByCategory(category);
	}

	
	public List<BookDetails> getBooksInfo() {
		return dao.getBooksInfo();
	}

	
	public List<UserDetails> showUsers() {
		return dao.showUsers();
	}

	
	public List<RequestBeans> showRequests() {
		return dao.showRequests();
	}

	
	public boolean bookIssue(UserDetails user, BookDetails book) {
		return dao.bookIssue(user, book);
	}

	
	public boolean isBookReceived(UserDetails user, BookDetails book) {
		return dao.isBookReceived(user, book);
	}

	

}//End of class

package com.capgemini.librarymanagementsystemcollections.service;

import java.util.List;

import com.capgemini.librarymanagementsystemcollections.dto.BookDetails;
import com.capgemini.librarymanagementsystemcollections.dto.RequestBeans;
import com.capgemini.librarymanagementsystemcollections.dto.UserDetails;


public interface UserService {
	boolean registerUser(UserDetails user);
	UserDetails loginUser(String email,String password);
	public RequestBeans bookRequest(UserDetails user, BookDetails book);
	public RequestBeans bookReturn(UserDetails user, BookDetails book);
	List<BookDetails> searchBookByTitle(String bookName);
	List<BookDetails> searchBookByAuthor(String author);
	List<BookDetails> searchBookByCategory(String category);
	List<BookDetails> getBooksInfo();

}

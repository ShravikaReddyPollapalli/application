package com.capgemini.librarymanagementsystemcollections.exception;

@SuppressWarnings("serial")
public class LMSException extends RuntimeException{
	public LMSException(String msg) {
		super(msg);
	}//End of LibraryManagementSystemException() method

}//End of class

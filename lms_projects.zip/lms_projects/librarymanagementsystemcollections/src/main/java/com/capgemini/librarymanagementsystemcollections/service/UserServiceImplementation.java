package com.capgemini.librarymanagementsystemcollections.service;

import java.util.List;

import com.capgemini.librarymanagementsystemcollections.dao.UserDAO;
import com.capgemini.librarymanagementsystemcollections.dto.BookDetails;
import com.capgemini.librarymanagementsystemcollections.dto.RequestBeans;
import com.capgemini.librarymanagementsystemcollections.dto.UserDetails;
import com.capgemini.librarymanagementsystemcollections.factory.LibraryFactory;


public class UserServiceImplementation implements UserService{

	private UserDAO dao = LibraryFactory.getUserDao();

	
	public boolean registerUser(UserDetails user) {
		return dao.registerUser(user);
	}

	
	public UserDetails loginUser(String email, String password) {
		return dao.loginUser(email, password);
	}

	
	public RequestBeans bookRequest(UserDetails user, BookDetails book) {
		return dao.bookRequest(user, book);
	}

	
	public RequestBeans bookReturn(UserDetails user, BookDetails book) {
		return dao.bookReturn(user, book);
	}

	
	public List<BookDetails> searchBookByTitle(String bookName) {
		return dao.searchBookByTitle(bookName);
	}

	
	public List<BookDetails> searchBookByAuthor(String author) {
		return dao.searchBookByAuthor(author);
	}

	
	public List<BookDetails> searchBookByCategory(String category) {
		return dao.searchBookByCategory(category);
	}

	
	public List<BookDetails> getBooksInfo() {
		return dao.getBooksInfo();
	}	

}//End of class

package com.capgemini.librarymanagementsystemcollections.db;

import java.util.LinkedList;

import com.capgemini.librarymanagementsystemcollections.dto.AdminDetails;
import com.capgemini.librarymanagementsystemcollections.dto.BookDetails;
import com.capgemini.librarymanagementsystemcollections.dto.RequestBeans;
import com.capgemini.librarymanagementsystemcollections.dto.UserDetails;


public class LibraryDB {
	public static final LinkedList<BookDetails> BOOKS = new LinkedList<BookDetails>(); 
	public static final LinkedList<AdminDetails> ADMIN = new LinkedList<AdminDetails>();
	public static final LinkedList<UserDetails> USER = new LinkedList<UserDetails>();
	public static final LinkedList<RequestBeans> REQUEST = new LinkedList<RequestBeans>();

public static void addToDB() {
	
	BOOKS.add(new BookDetails(101010,"java","james","gosling","coding"));
	BOOKS.add(new BookDetails(101011,"history","tom","henry feild","world"));
	BOOKS.add(new BookDetails(101012,"angular","misko","adam","js"));
	BOOKS.add(new BookDetails(101013,"computers","charles","aborns","programing"));

}


}
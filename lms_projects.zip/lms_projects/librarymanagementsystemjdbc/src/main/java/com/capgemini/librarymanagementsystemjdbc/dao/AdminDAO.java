package com.capgemini.librarymanagementsystemjdbc.dao;

import java.util.List;

import com.capgemini.librarymanagementsystemjdbc.dto.BookBeans;
import com.capgemini.librarymanagementsystemjdbc.dto.BookIssueDetails;
import com.capgemini.librarymanagementsystemjdbc.dto.RequestDetails;
import com.capgemini.librarymanagementsystemjdbc.dto.UserBeans;

public interface AdminDAO {
	List<BookIssueDetails> bookHistoryDetails(int uId);

	List<RequestDetails> showRequests();

	List<BookIssueDetails> showIssuedBooks();

	List<UserBeans> showUsers();

	boolean addBook(BookBeans book);

	boolean removeBook(int bId);

	boolean updateBook(BookBeans book);

	boolean issueBook(int bId,int uId);



}

package com.capgemini.librarymanagementsystemjdbc.service;

import java.util.List;

import com.capgemini.librarymanagementsystemjdbc.dao.LibrarianDAO;
import com.capgemini.librarymanagementsystemjdbc.dto.BookBeans;
import com.capgemini.librarymanagementsystemjdbc.dto.UserBeans;
import com.capgemini.librarymanagementsystemjdbc.factory.LibraryFactory;

public class LibrarianServiceImplementation implements LibrarianService{
	private LibrarianDAO dao=LibraryFactory.getLibrarianStudentDAO();
	
	public List<BookBeans> searchBookById(int bId) {
		return dao.searchBookById(bId);
	}

	
	public List<BookBeans> searchBookByTitle(String bookName) {
		return dao.searchBookByTitle(bookName);
	}

	
	public List<BookBeans> searchBookByAuthor(String authorName) {
		return dao.searchBookByAuthor(authorName);
	}

	
	public List<BookBeans> getBooksInfo() {
		return dao.getBooksInfo();
	}

	
	public boolean register(UserBeans user) {
		return dao.register(user);
	}

	
	public UserBeans login(String email, String password) {
		return dao.login(email, password);
	}

	
	public boolean updatePassword(String email, String password, String newPassword, String role) {
		return dao.updatePassword(email, password, newPassword, role);
	}
}


package com.capgemini.librarymanagementsystemjdbc.controller;

public class LibraryController extends Thread {
	public static void main(String[] args) {
		Library.doReg();
	}//End of main method
	}//End of class

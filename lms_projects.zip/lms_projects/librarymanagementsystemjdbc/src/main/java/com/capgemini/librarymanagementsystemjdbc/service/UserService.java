package com.capgemini.librarymanagementsystemjdbc.service;

import java.util.List;

import com.capgemini.librarymanagementsystemjdbc.dto.BorrowBook;



public interface UserService {
	boolean request(int uId, int bId);
	boolean returnBook(int bId,int uId,String status);
	List<BorrowBook> borrowedBook(int uId);
}

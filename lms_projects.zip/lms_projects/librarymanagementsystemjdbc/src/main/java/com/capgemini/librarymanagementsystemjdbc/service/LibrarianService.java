package com.capgemini.librarymanagementsystemjdbc.service;

import java.util.List;

import com.capgemini.librarymanagementsystemjdbc.dto.BookBeans;
import com.capgemini.librarymanagementsystemjdbc.dto.UserBeans;

public interface LibrarianService {
	List<BookBeans> searchBookById(int bId);
	List<BookBeans> searchBookByTitle(String bookName);
	List<BookBeans> searchBookByAuthor(String authorName);
	List<BookBeans> getBooksInfo();

	boolean register(UserBeans user);
	UserBeans login(String email,String password);
	boolean updatePassword(String email,String password,String newPassword,String role);
}

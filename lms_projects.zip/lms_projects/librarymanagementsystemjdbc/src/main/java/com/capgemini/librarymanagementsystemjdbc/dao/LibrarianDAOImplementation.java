package com.capgemini.librarymanagementsystemjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.librarymanagementsystemjdbc.dto.BookBeans;
import com.capgemini.librarymanagementsystemjdbc.dto.UserBeans;
import com.capgemini.librarymanagementsystemjdbc.exception.LibraryManagementSystemException;
import com.capgemini.librarymanagemnetsystemjdbc.utility.LibraryUtility;

public class LibrarianDAOImplementation implements LibrarianDAO{

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet rs = null;
	Statement stmt = null;


	@Override
	public List<BookBeans> searchBookById(int bId) {

		connection = LibraryUtility.getConnection();

		try (PreparedStatement statement = connection.prepareStatement(Queries.searchIdQuery);) {
			statement.setInt(1, bId);
			rs = statement.executeQuery();
			List<BookBeans> beans = new ArrayList<BookBeans>();
			while (rs.next()) {
				BookBeans bean = new BookBeans();
				bean.setBId(rs.getInt("bId"));
				bean.setBookName(rs.getString("bookName"));
				bean.setAuthor(rs.getString("authorName"));
				bean.setCategory(rs.getString("bookCategory"));
				bean.setPublisher(rs.getString("publisherName"));
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public List<BookBeans> searchBookByTitle(String bookName) {

		connection = LibraryUtility.getConnection();

		try (PreparedStatement statement = connection.prepareStatement(Queries.titleQuery);) {

			statement.setString(1, bookName);
			rs = statement.executeQuery();
			List<BookBeans> beans = new ArrayList<BookBeans>();
			while (rs.next()) {
				BookBeans bean = new BookBeans();
				bean.setBId(rs.getInt("bId"));
				bean.setBookName(rs.getString("bookName"));
				bean.setAuthor(rs.getString("authorName"));
				bean.setCategory(rs.getString("bookCategory"));
				bean.setPublisher(rs.getString("publisherName"));
				beans.add(bean);
			}
			return beans;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public List<BookBeans> searchBookByAuthor(String authorName) {

		connection = LibraryUtility.getConnection();

		try (PreparedStatement statement = connection.prepareStatement(Queries.authorQuery);) {

			statement.setString(1, authorName);
			rs = statement.executeQuery();
			List<BookBeans> beans = new ArrayList<BookBeans>();
			while (rs.next()) {
				BookBeans bean = new BookBeans();
				bean.setBId(rs.getInt("bId"));
				bean.setBookName(rs.getString("bookName"));
				bean.setAuthor(rs.getString("authorName"));
				bean.setCategory(rs.getString("bookCategory"));
				bean.setPublisher(rs.getString("publisherName"));
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public List<BookBeans> getBooksInfo() {

		connection = LibraryUtility.getConnection();

		try (Statement stmt = (Statement) connection.createStatement();) {
			rs = stmt.executeQuery(Queries.getAllBooksQuery);
			List<BookBeans> beans = new ArrayList<BookBeans>();
			while (rs.next()) {
				BookBeans bean = new BookBeans();
				bean.setBId(rs.getInt("bId"));
				bean.setBookName(rs.getString("bookName"));
				bean.setAuthor(rs.getString("authorName"));
				bean.setCategory(rs.getString("bookCategory"));
				bean.setPublisher(rs.getString("publisherName"));
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}


	}

	@Override
	public boolean register(UserBeans user) {

		connection = LibraryUtility.getConnection();

		try (PreparedStatement statement = connection.prepareStatement(Queries.registerQuery);) {

			statement.setInt(1, user.getuId());
			statement.setString(2, user.getFirstName());
			statement.setString(3, user.getLastName());
			statement.setString(4, user.getEmail());
			statement.setString(5, user.getPassword());
			statement.setLong(6, user.getMobile());
			statement.setString(7, user.getRole());
			int count = statement.executeUpdate();
			if ((user.getEmail().isEmpty()) && (count == 0)) {
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public UserBeans login(String email, String password) {

		connection = LibraryUtility.getConnection();

		try (PreparedStatement statement = connection.prepareStatement(Queries.loginQuery);) {

			statement.setString(1, email);
			statement.setString(2, password);
			rs = statement.executeQuery();
			if (rs.next()) {
				UserBeans bean = new UserBeans();
				bean.setuId(rs.getInt("uId"));
				bean.setFirstName(rs.getString("firstName"));
				bean.setLastName(rs.getString("lastName"));
				bean.setEmail(rs.getString("email"));
				bean.setPassword(rs.getString("password"));
				bean.setMobile(rs.getLong("mobileNumber"));
				bean.setRole(rs.getString("role"));
				return bean;
			} else {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public boolean updatePassword(String email, String password, String newPassword, String role) {

		connection = LibraryUtility.getConnection();

		try (PreparedStatement statement = connection.prepareStatement(Queries.updatePasswordQuery1);) {
			statement.setString(1, email);
			statement.setString(2, role);
			rs = statement.executeQuery();
			if (rs.next()) {
				try (PreparedStatement pstmt = connection.prepareStatement(Queries.updatePasswordQuery2);) {
					pstmt.setString(1, newPassword);
					pstmt.setString(2, email);
					pstmt.setString(3, password);
					int count = pstmt.executeUpdate();
					if (count != 0) {
						return true;
					} else {
						return false;
					}
				}
			} else {
				throw new LibraryManagementSystemException("user doesnt exist");
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		}

	}


}

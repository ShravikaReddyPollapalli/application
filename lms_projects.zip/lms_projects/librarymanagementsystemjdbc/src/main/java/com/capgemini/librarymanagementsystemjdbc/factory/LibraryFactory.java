package com.capgemini.librarymanagementsystemjdbc.factory;

import com.capgemini.librarymanagementsystemjdbc.dao.AdminDAO;
import com.capgemini.librarymanagementsystemjdbc.dao.AdminDAOImplementation;
import com.capgemini.librarymanagementsystemjdbc.dao.LibrarianDAO;
import com.capgemini.librarymanagementsystemjdbc.dao.LibrarianDAOImplementation;
import com.capgemini.librarymanagementsystemjdbc.dao.UserDAO;
import com.capgemini.librarymanagementsystemjdbc.dao.UserDAOImplementation;
import com.capgemini.librarymanagementsystemjdbc.service.AdminService;
import com.capgemini.librarymanagementsystemjdbc.service.AdminServiceImplementation;
import com.capgemini.librarymanagementsystemjdbc.service.LibrarianService;
import com.capgemini.librarymanagementsystemjdbc.service.LibrarianServiceImplementation;
import com.capgemini.librarymanagementsystemjdbc.service.UserService;
import com.capgemini.librarymanagementsystemjdbc.service.UserServiceImplementation;
	
	public class LibraryFactory {
		public static AdminDAO getLibrarianDAO() {
			return new AdminDAOImplementation();
		}
		
		public static UserDAO getStudentDAO() {
			return new UserDAOImplementation();
		}
		
		public static LibrarianDAO getLibrarianStudentDAO() {
			return new LibrarianDAOImplementation();
		}
		
		public static AdminService getAdminService() {
			return new AdminServiceImplementation();
		}
		
		public static UserService getUserService() {
			return new UserServiceImplementation();
		}
		
		public static LibrarianService getLibrarianStudentService() {
			return new LibrarianServiceImplementation();
		}

	}
package com.capgemini.librarymanagementsystemjdbc.exception;

@SuppressWarnings("serial")
public class LibraryManagementSystemException extends RuntimeException{
	public LibraryManagementSystemException(String message) {
		super(message);
	}
}

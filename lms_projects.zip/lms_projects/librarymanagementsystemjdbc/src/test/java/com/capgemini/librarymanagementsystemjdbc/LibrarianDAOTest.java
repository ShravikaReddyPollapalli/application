package com.capgemini.librarymanagementsystemjdbc;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.capgemini.librarymanagementsystemjdbc.dao.LibrarianDAO;
import com.capgemini.librarymanagementsystemjdbc.dao.LibrarianDAOImplementation;
import com.capgemini.librarymanagementsystemjdbc.dto.BookBeans;
import com.capgemini.librarymanagementsystemjdbc.dto.UserBeans;

public class LibrarianDAOTest {
	private LibrarianDAO dao = new LibrarianDAOImplementation();

	@Test
	public void testRegisterValid() {
		UserBeans bean = new UserBeans();
		bean.setuId(100005);
		bean.setFirstName("sharada");
		bean.setLastName("gangishetti");
		bean.setEmail("sharada@gmail.com");
		bean.setPassword("Sharada@123");
		bean.setRole("student");
		boolean check = dao.register(bean);
		Assertions.assertTrue(check);		
	}

	@Test
	public void testRegisterInvalid() {
		UserBeans bean = new UserBeans();
		bean.setuId(100005);
		bean.setFirstName("sharada");
		bean.setLastName("gangishetti");
		bean.setEmail("sharada@gmail.com");
		bean.setPassword("Sharada@123");
		bean.setRole("student");
		boolean check = dao.register(bean);
		Assertions.assertFalse(check);
	}

	@Test
	public void testLoginValid() {
		UserBeans info = dao.login("vyshu@gmail.com", "vyshU@123");
		Assertions.assertNotNull(info);
	}

	@Test
	public void testLoginInvalid() {
		UserBeans info = dao.login("vyshu@gmail.com", "vyshU123");
		Assertions.assertNull(info);
	}

	@Test
	public void testSearchBookByIdValid() {
		List<BookBeans> info = dao.searchBookById(101);
		Assertions.assertNotNull(info);
		Assertions.assertEquals(1, info.size());

	}

	@Test
	public void testSearchBookByIdInvalid() {
		List<BookBeans> info = dao.searchBookById(109);
		Assertions.assertNotNull(info);
		Assertions.assertEquals(0, info.size());		
	}

	@Test
	public void testSearchBookByTitleValid() {
		List<BookBeans> info = dao.searchBookByTitle("MM");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(1, info.size());		
	}

	@Test
	public void testSearchBookByTitleInvalid() {
		List<BookBeans> info = dao.searchBookByTitle("Maths");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(0, info.size());		
	}

	@Test
	public void testSearchBookByAuthorValid() {
		List<BookBeans> info = dao.searchBookByAuthor("sharma");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(1, info.size());		
	}

	@Test
	public void testSearchBookByAuthorInvalid() {
		List<BookBeans> info = dao.searchBookByAuthor("Jain");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(0, info.size());	
	}

	@Test
	public void testBooksInfoValid() {
		List<BookBeans> info = dao.getBooksInfo();
		Assertions.assertNotNull(info);
		Assertions.assertEquals(5, info.size());
	}

	@Test
	public void testBooksInfoInvalid() {
		List<BookBeans> info = dao.getBooksInfo();
		Assertions.assertNotNull(info);
		Assertions.assertNotEquals(6, info.size());
	}

	@Test
	public void testUpdatePasswordValid() {
		boolean check = dao.updatePassword("vyshu@gmail.com", "Vyshu@123", "Admin@123", "admin");
		Assertions.assertTrue(check);
	}

	@Test
	public void testUpdatePasswordInvalid() {
		boolean check = dao.updatePassword("vyshu@gmail.com", "Vyshu@123", "Admin@123", "student");
		Assertions.assertFalse(check);
	}




}

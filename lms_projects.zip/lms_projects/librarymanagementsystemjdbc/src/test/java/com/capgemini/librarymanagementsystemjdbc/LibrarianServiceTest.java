package com.capgemini.librarymanagementsystemjdbc;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.capgemini.librarymanagementsystemjdbc.dto.BookBeans;
import com.capgemini.librarymanagementsystemjdbc.dto.UserBeans;
import com.capgemini.librarymanagementsystemjdbc.service.LibrarianService;
import com.capgemini.librarymanagementsystemjdbc.service.LibrarianServiceImplementation;

public class LibrarianServiceTest {
	private LibrarianService service = new LibrarianServiceImplementation();

	@Test
	public void testRegisterValid() {
		UserBeans bean = new UserBeans();
		bean.setuId(100005);
		bean.setFirstName("sharada");
		bean.setLastName("gangishetti");
		bean.setEmail("sharada@gmail.com");
		bean.setPassword("Sharada@123");
		bean.setRole("student");
		boolean check = service.register(bean);
		Assertions.assertTrue(check);		
	}

	@Test
	public void testRegisterInvalid() {
		UserBeans bean = new UserBeans();
		bean.setuId(100005);
		bean.setFirstName("sharada");
		bean.setLastName("gangishetti");
		bean.setEmail("sharada@gmail.com");
		bean.setPassword("Sharada@123");
		bean.setRole("student");
		boolean check = service.register(bean);
		Assertions.assertFalse(check);
	}

	@Test
	public void testLoginValid() {
		UserBeans info = service.login("vyshu@gmail.com", "Vyshu@123");
		Assertions.assertNotNull(info);
	}

	@Test
	public void testLoginInvalid() {
		UserBeans info = service.login("vyshu@gmail.com", "Vyshu123");
		Assertions.assertNull(info);
	}

	@Test
	public void testSearchBookByIdValid() {
		List<BookBeans> info = service.searchBookById(101);
		Assertions.assertNotNull(info);
		Assertions.assertEquals(1, info.size());

	}

	@Test
	public void testSearchBookByIdInvalid() {
		List<BookBeans> info = service.searchBookById(109);
		Assertions.assertNotNull(info);
		Assertions.assertEquals(0, info.size());		
	}

	@Test
	public void testSearchBookByTitleValid() {
		List<BookBeans> info = service.searchBookByTitle("MM");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(1, info.size());		
	}

	@Test
	public void testSearchBookByTitleInvalid() {
		List<BookBeans> info = service.searchBookByTitle("Maths");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(0, info.size());		
	}

	@Test
	public void testSearchBookByAuthorValid() {
		List<BookBeans> info = service.searchBookByAuthor("sharma");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(1, info.size());		
	}

	@Test
	public void testSearchBookByAuthorInvalid() {
		List<BookBeans> info = service.searchBookByAuthor("Jain");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(0, info.size());	
	}

	@Test
	public void testBooksInfoValid() {
		List<BookBeans> info = service.getBooksInfo();
		Assertions.assertNotNull(info);
		Assertions.assertEquals(5, info.size());
	}

	@Test
	public void testBooksInfoInvalid() {
		List<BookBeans> info = service.getBooksInfo();
		Assertions.assertNotNull(info);
		Assertions.assertNotEquals(6, info.size());
	}

	@Test
	public void testUpdatePasswordValid() {
		boolean check = service.updatePassword("vyshu@gmail.com", "Vyshu@123", "Admin@123", "admin");
		Assertions.assertTrue(check);
	}

	@Test
	public void testUpdatePasswordInvalid() {
		boolean check = service.updatePassword("vyshu@gmail.com", "Vyshu@123", "Admin@123", "student");
		Assertions.assertFalse(check);
	}





}

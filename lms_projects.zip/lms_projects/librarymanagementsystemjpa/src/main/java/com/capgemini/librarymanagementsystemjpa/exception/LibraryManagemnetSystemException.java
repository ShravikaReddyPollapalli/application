package com.capgemini.librarymanagementsystemjpa.exception;

@SuppressWarnings("serial")
public class LibraryManagemnetSystemException extends RuntimeException{
	public LibraryManagemnetSystemException(String message) {
		super(message);
	}
}

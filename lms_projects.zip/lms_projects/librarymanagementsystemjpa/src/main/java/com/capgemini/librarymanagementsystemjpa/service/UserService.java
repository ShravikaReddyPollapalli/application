package com.capgemini.librarymanagementsystemjpa.service;

import java.util.List;

import com.capgemini.librarymanagementsystemjpa.dto.BookDetails;
import com.capgemini.librarymanagementsystemjpa.dto.UserDetails;



public interface UserService {
	boolean register(UserDetails user);
	UserDetails login(String email,String password);	
	boolean updatePassword(int id,String password,String newPassword,String role);

	List<BookDetails> searchBookById(int bId);
	List<BookDetails> searchBookByTitle(String bookName);
	List<BookDetails> searchBookByAuthor(String authorName);
	List<BookDetails> getBooksInfo();

}

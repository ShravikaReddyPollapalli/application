package com.capgemini.librarymanagementsystemjpa.controller;

public class LibraryController extends Thread {
	public static void main(String[] args) {
		Library.doReg();
	}
	
}

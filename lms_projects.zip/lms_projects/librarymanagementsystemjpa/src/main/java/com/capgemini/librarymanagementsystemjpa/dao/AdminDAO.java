package com.capgemini.librarymanagementsystemjpa.dao;

import java.util.List;

import com.capgemini.librarymanagementsystemjpa.dto.BookDetails;
import com.capgemini.librarymanagementsystemjpa.dto.BookIssueDetails;
import com.capgemini.librarymanagementsystemjpa.dto.RequestDetails;
import com.capgemini.librarymanagementsystemjpa.dto.UserDetails;

public interface AdminDAO {
	List<Integer> bookHistoryDetails(int uId);
	List<RequestDetails> showRequests();
	List<BookIssueDetails> showIssuedBooks();
	List<UserDetails> showUsers();

	boolean addBook(BookDetails book);
	boolean removeBook(int bId);
	boolean updateBook(BookDetails book);
	boolean issueBook(int bId,int uId);
}

package com.capgemini.librarymanagementsystemjpa.factory;

import com.capgemini.librarymanagementsystemjpa.dao.AdminDAO;
import com.capgemini.librarymanagementsystemjpa.dao.AdminDAOImplementation;
import com.capgemini.librarymanagementsystemjpa.dao.LibrarianDAO;
import com.capgemini.librarymanagementsystemjpa.dao.LibrarianDAOImplementation;
import com.capgemini.librarymanagementsystemjpa.dao.UserDAO;
import com.capgemini.librarymanagementsystemjpa.dao.UserDAOImplementation;
import com.capgemini.librarymanagementsystemjpa.service.AdminService;
import com.capgemini.librarymanagementsystemjpa.service.AdminServiceImplementation;
import com.capgemini.librarymanagementsystemjpa.service.LibrarianService;
import com.capgemini.librarymanagementsystemjpa.service.LibrarianServiceImplementation;
import com.capgemini.librarymanagementsystemjpa.service.UserService;
import com.capgemini.librarymanagementsystemjpa.service.UserServiceImplementation;
	
	public class LibraryFactory {
		public static UserDAO getUserDAO() {
			return new UserDAOImplementation();
		}
		public static UserService getUserService() {
			return new UserServiceImplementation();
		}
		
		public static AdminDAO getAdminDAO() {
			return new AdminDAOImplementation();
		}
		public static AdminService getAdminService() {
			return new AdminServiceImplementation();
		}
		
		public static LibrarianDAO getLibrarianUserDAO() {
			return new LibrarianDAOImplementation();
		}
		public static LibrarianService getLibrarianUserService() {
			return new LibrarianServiceImplementation();
		}
	}
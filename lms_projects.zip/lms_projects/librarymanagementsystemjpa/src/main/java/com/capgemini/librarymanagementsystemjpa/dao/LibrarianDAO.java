package com.capgemini.librarymanagementsystemjpa.dao;

import java.util.List;

import com.capgemini.librarymanagementsystemjpa.dto.BorrowBook;

public interface LibrarianDAO {
	boolean request(int uId, int bId);
	boolean returnBook(int bId,int uId,String status);
	List<BorrowBook> borrowedBook(int uId);
}

package com.capgemini.librarymanagementsystemjpa.service;

import java.util.List;

import com.capgemini.librarymanagementsystemjpa.dto.BorrowBook;

public interface LibrarianService {
	boolean request(int uId, int bId);
	boolean returnBook(int bId,int uId,String status);
	List<BorrowBook> borrowedBook(int uId);
}

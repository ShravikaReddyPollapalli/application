package com.capgemini.librarymanagementsystemjpa.service;

import java.io.FileInputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.librarymanagementsystemjpa.dto.BookDetails;
import com.capgemini.librarymanagementsystemjpa.dto.BookIssueDetails;
import com.capgemini.librarymanagementsystemjpa.dto.BorrowBook;
import com.capgemini.librarymanagementsystemjpa.dto.RequestDetails;
import com.capgemini.librarymanagementsystemjpa.exception.LibraryManagemnetSystemException;

public class LibrarianServiceImplementation implements LibrarianService{
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	int noOfBooks;
	
	public boolean request(int uId, int bId) {

		int count=0;
		try(FileInputStream info = new FileInputStream("db.properties");) {
			Properties pro = new Properties();
			pro.load(info);
			factory = Persistence.createEntityManagerFactory("TestPersistence");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			String jpql = "select b from BookDetails b where b.bId=:bId";
			TypedQuery<BookDetails> query = manager.createQuery(jpql,BookDetails.class);
			query.setParameter("bId", bId);
			@SuppressWarnings("rawtypes")
			List rs = query.getResultList();
			if(rs != null) {
				String jpql1 = "select b from BorrowedBooksDetails b where b.uId=:uId and b.bId=:bId";
				TypedQuery<BorrowBook> query1 = (TypedQuery<BorrowBook>) manager.createQuery(jpql1,BorrowBook.class);
				query1.setParameter("uId", uId);
				query1.setParameter("bId", bId);
				@SuppressWarnings("rawtypes")
				List rs1 = query1.getResultList();
				if( rs1.isEmpty() || rs1==null ) {
					String jpql2 = "select b from BookIssueDetails b where b.uId=:uId";
					TypedQuery<BookIssueDetails> query2 = (TypedQuery<BookIssueDetails>) manager.createQuery(jpql2,BookIssueDetails.class);
					query2.setParameter("uId", uId);
					List<BookIssueDetails> rs2 = query2.getResultList();
					for(@SuppressWarnings("unused") BookIssueDetails p : rs2) {
						noOfBooks = count++;
					}
					if(noOfBooks<3) {
						Query bookName = manager.createQuery("select b.bookName from BookDetails b where b.bId=:bookId");
						bookName.setParameter("bookId", bId);
						@SuppressWarnings("rawtypes")
						List book = bookName.getResultList();
						Query email = manager.createQuery("select u.email from UserDetails u where u.uId=:user_Id");
						email.setParameter("user_Id", uId);
						@SuppressWarnings("rawtypes")
						List userEmail = email.getResultList();
						transaction.begin();
						RequestDetails request = new RequestDetails();
						request.setuId(uId);
						request.setbId(bId);
						request.setEmail(userEmail.get(0).toString());
						request.setBookName(book.get(0).toString());
						manager.persist(request);
						transaction.commit();
						return true;

					}else {
						throw new LibraryManagemnetSystemException("You have crossed the book limit");
					}
				}else {
					throw new LibraryManagemnetSystemException("You have already borrowed the requested book");
				}
			}else {
				throw new LibraryManagemnetSystemException("The book with requested id is not present");
			}

		} catch (Exception e) {
			System.err.println(e.getMessage());
			transaction.rollback();
			return false;
		} finally {
			manager.close();
			factory.close();
		}

	}
	public boolean returnBook(int bId, int uId, String status) {

		try(FileInputStream info = new FileInputStream("db.properties");){
			Properties pro = new Properties();
			pro.load(info);
			factory = Persistence.createEntityManagerFactory("TestPersistence");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			String jpql = "select b from BookBean b where b.bId=:bId";
			TypedQuery<BookDetails> query = manager.createQuery(jpql,BookDetails.class);
			query.setParameter("bId", bId);
			BookDetails rs = query.getSingleResult();
			if(rs != null) {
				String jpql1 = "select b from BookIssueBean b where b.bId=:bId and b.uId=:uId ";
				TypedQuery<BookIssueDetails> query1 = manager.createQuery(jpql1,BookIssueDetails.class);
				query1.setParameter("bId", bId);
				query1.setParameter("uId", uId);
				BookIssueDetails rs1 = query1.getSingleResult();
				if(rs1 != null) {
					Date issueDate = rs1.getIssueDate();
					Calendar cal = Calendar.getInstance();
					Date returnDate = cal.getTime();
					long difference = issueDate.getTime() - returnDate.getTime();
					float daysBetween = (difference / (1000*60*60*24));
					if(daysBetween>7.0) {
						
						float fine = daysBetween*5;
						System.out.println("The user has to pay the fine of the respective book of Rs:"+fine);
						if(status=="yes") {
							transaction.begin();
							manager.remove(rs1);
							transaction.commit();
							transaction.begin();
							String jpql3 = "select b from BooksBorrowedDetails b  where b.bId=:bId and b.uId=:uId";
							Query query3 = manager.createQuery(jpql3);
							query3.setParameter("bId", bId);
							query3.setParameter("uId", uId);
							BorrowBook bbb = (BorrowBook) query3.getSingleResult();
							
							manager.remove(bbb);
							transaction.commit();

							transaction.begin();
							String jpql4 = "select r from RequestDetails r where r.bId=:bId and r.uId=:uId";
							Query query4 = manager.createQuery(jpql4);
							query4.setParameter("bId", bId);
							query4.setParameter("uId", uId);
							RequestDetails rdb = (RequestDetails) query4.getSingleResult();
							
							manager.remove(rdb);
							transaction.commit();
							return true;
						}else {
							throw new LibraryManagemnetSystemException("The User has to pay fine for delaying book return");
						}
					}else {
						transaction.begin();
												manager.remove(rs1);
						transaction.commit();


						transaction.begin();
						String jpql3 = "select b from BorrowedBooks b  where b.bId=:bId and b.uId=:uId";
						Query query3 = manager.createQuery(jpql3);
						query3.setParameter("bId", bId);
						query3.setParameter("uId", uId);
						BorrowBook bbb = (BorrowBook) query3.getSingleResult();
						
						manager.remove(bbb);
						transaction.commit();

						transaction.begin();
						String jpql4 = "select r from RequestDetails r where r.bId=:bId and r.uId=:uId";
						Query query4 = manager.createQuery(jpql4);
						query4.setParameter("bId", bId);
						query4.setParameter("uId", uId);
						RequestDetails rdb = (RequestDetails) query4.getSingleResult();
						
						manager.remove(rdb);
						transaction.commit();
						return true;
					}

				}else {
					throw new LibraryManagemnetSystemException("This respective user hasn't borrowed any book");
				}
			}else {
				throw new LibraryManagemnetSystemException("book doesnt exist");
			}

		}catch (Exception e) {
			System.err.println(e.getMessage());
			transaction.rollback();
			return false;
		}finally {
			manager.close();
			factory.close();
		}
	}



	
	public List<BorrowBook> borrowedBook(int uId) {


		try(FileInputStream info = new FileInputStream("db.properties");) {
			Properties pro = new Properties();
			pro.load(info);
			factory = Persistence.createEntityManagerFactory("TestPersistence");
			manager = factory.createEntityManager();
			String jpql = "select b from BooksBorrowedDetails b where b.uId=:uId";
			TypedQuery<BorrowBook> query = manager.createQuery(jpql,BorrowBook.class);
			query.setParameter("uId", uId);
			List<BorrowBook> recordList = query.getResultList();
			return recordList; 
		}catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}finally {
			manager.close();
			factory.close();
		}


	}

}
